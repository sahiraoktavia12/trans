// app/dashboard/page.tsx
export default function DashboardPage() {
  return (
    <div className="text-gray-800">
      <h1 className="text-2xl font-bold mb-4">Dashboard</h1>
      <p>Selamat datang di dashboard Anda!</p>
    </div>
  );
}
